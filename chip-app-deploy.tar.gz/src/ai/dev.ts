import { config } from 'dotenv';
config();

import '@/ai/flows/chip-suggestion-bom.ts';
import '@/ai/flows/chip-suggestion.ts';